<?php
// php file that contains the common database connection code
include "dbFunctions.php";

$name = $_POST['name'];
$gender = $_POST['gender'];
$birthdate = $_POST['birthdate'];
$username = $_POST['username'];
$password = $_POST['password'];

$query = "INSERT INTO users
          (name,gender,birthdate,username,password) 
          VALUES 
          ('$name','$gender','$birthdate','$username','$password')";

$status = mysqli_query($link, $query);

if ($status) {
    $message = "<p>Your new account has been successfully created. 
                You are now ready to <a href='login.php'>login</a>.</p>";
}
else {
    $message = "Account Creation Failed";
}

mysqli_close($link);

?>
<!DOCTYPE HTML>
<html>
    <link href="stylesheets/style.css" rel="stylesheet" type="text/css"/>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
        <title>FYP</title>
    </head>
    <body>
        <h3>Republic Polytechnic - Register</h3>
        <?php
        echo $message;
        ?>
    </body>
</html>