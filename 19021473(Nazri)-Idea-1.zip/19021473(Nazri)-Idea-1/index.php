<!DOCTYPE html>
<?php session_start();
$msg="";

if(!isset($_SESSION['username'])){
    $msg="<h3>Republic Polytechnic</h3>";
    $msg .="<h4>Please <a href='login.php'>Login</a> .</h4>";
}else{
    $msg="<h3> Hi " . $_SESSION['username'] . "!</h3>";
    $msg .="<h4> Full Name:  " . $_SESSION['name'] . "</h4>";
    $msg .="<h4> Birth Date:  " . $_SESSION['birthdate'] . "</h4>";
    $msg .="<a href='logout.php'>Logout</a>";
}
?>
<html>
    <link href="stylesheets/style.css" rel="stylesheet" type="text/css"/>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Republic Polytechnic</title>
    </head>
    <body>
        <?php
        echo $msg;
        ?>
    </body>
</html>