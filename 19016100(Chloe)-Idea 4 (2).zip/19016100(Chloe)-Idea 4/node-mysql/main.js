const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const port = 5000
var mysql = require('mysql')
app.use(express.static('public'))

app.use(bodyParser.urlencoded({extended: false})) //access input data

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'fyp'
  });


connection.connect(function(err){
    if (err) throw err;
    console.log('Connected...');
})



app.get('/', function(req, res){
  res.sendFile('register2.html', { root: __dirname })
});

app.get('/login', function(req, res){
    res.sendFile('login.html', { root: __dirname })
  });

//app.get('/login', function(req, res){
  //  connection.query("SELECT name FROM users", function (err, rows, fields){
    //    if (err) throw err
      //  res.render('login', {title: 'Login',
        //    message: 'Login Successfull.'})
    //})
//});

//app.get('/submit', function(req, res){
 //   console.log(req.body);

   // var sql="insert into users values(null, '"+ req.body.username +"', '"+ req.body.pass +"')";
    //connection.query(sql, function (err) {
      //  if (err) throw err
        //    res.render('index', {title: 'Account Registered',
          //  message: 'Account Created Successfully.'})
      
      //})
      //connection.end();
//})







app.get('/register2', function(req, res){
    res.sendFile('register2.html', { root: __dirname })
  });

app.get('/dashboard', function(req, res){
    res.sendFile('dashboard.html', { root: __dirname })
  });


app.listen(port, () => {
  console.log(`App listening at http://localhost:${port}`)
})

app.set('view engine', 'pug')






