<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>FYP</title>
    </head>
    <body>
        <h3>Republic Polytechnic</h3>
        <form method="post" action="doLogin.php">
            <fieldset style="width:300px;">
                <table>
                    <tr>
                        <td><label for="idUsername">Username:</label></td>
                        <td><input type="text" id="idUsername" name="username"/></td>
                    </tr>
                    <tr>
                        <td><label for="idPassword">Password:</label></td>
                        <td><input type="password" id="idPassword" name="password"/></td>
                    </tr>
                </table>
            </fieldset>
            <br>
            <input type="submit" value="Login" name="submit"/>
        </form>
        <br/><br/>
        <a href="register.php">Register</a>
    </body>
</html>
