<!DOCTYPE html>
<html>
    <link href="stylesheets/style.css" rel="stylesheet" type="text/css"/>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Republic Polytechnic</title>
        <style>
            .col-right-align { text-align: right;}
        </style>
    </head>
    <body>
        <h3>Republic Polytechnic - Register</h3>
        <h4>Please fill the following fields for registration.</h4>
        <form method="post" action="doRegister.php">
            <fieldset style="width:500px;">
                <table>
                    <tr>
                        <td class="col-right-align"><label>Name:</label></td>
                        <td><input type="text" name="name"/></td>
                    </tr>
                    <tr>
                        <td class="col-right-align"><label>Gender:</label></td>
                        <td>
                            <input type="radio" name="gender" value="male"/>male
                            <input type="radio" name="gender" value="female"/>female
                        </td>
                    </tr>
                    <tr>
                        <td class="col-right-align"><label>Birthdate:</label></td>
                        <td><input type="date" name="birthdate"/></td>
                    </tr>
                    <tr>
                        <td colspan="2"><hr/></td>
                    </tr>
                    <tr>
                        <td class="col-right-align"><label>Username:</label></td>
                        <td><input type="text" name="username" required/></td>
                    </tr>
                    <tr>
                        <td class="col-right-align"><label>Password:</label></td>
                        <td><input type="password" name="password" required/></td>
                    </tr>
                </table>	
            </fieldset></br>
            <input type="submit" value="Sign Up" name="submit"/>
        </form> 
    </body>
</html>
