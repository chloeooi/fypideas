<?php
session_start();

// php file that contains the common database connection code
include "dbFunctions.php";

$user = $_SESSION['username'];

$msg = "";

$queryCheck = "SELECT password FROM users
                WHERE username = '$user'";
$status = mysqli_query($link, $queryCheck) or die(mysqli_error($link));
$dataone = array();
while ($row = mysqli_fetch_assoc($status)) {
    $dataone[] = $row['password'];
}
$stringone = implode(" ",$dataone);
strtolower($stringone);
strtolower($a);
if (str_contains($stringone, $a)) {
    $message = "<p>Account successfully verified. 
                You may proceed to <a href='index.php'>home</a>.</p>";
}
else {
    $message = "Account Authentication Failed";
}

mysqli_close($link);

?>
<!DOCTYPE HTML>
<html>
    <link href="stylesheets/style.css" rel="stylesheet" type="text/css"/>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
        <title>FYP</title>
    </head>
    <body>
        <h3>Republic Polytechnic - Register</h3>
        <?php
        echo $message;
        ?>
    </body>
</html>