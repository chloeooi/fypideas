import random

N = 6
images_ = random.sample(range(10, 46), N * N)
images = []
for i in range(0, N * N, N):
    images.append(images_[i:i + N])

print(images)
