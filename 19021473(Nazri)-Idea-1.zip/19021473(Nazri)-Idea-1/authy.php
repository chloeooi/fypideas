<!DOCTYPE html>
<?php
session_start();

// php file that contains the common database connection code
include "dbFunctions.php";

$username = $_SESSION['username'];

$query = "SELECT password from users
        WHERE username = '$username'";
$result = mysqli_query($link, $query) or die(mysqli_error($link));
$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row['password'];
}
$string = implode(" ",$data);   
$alphabet = range('!', 'z');
$string1 = implode("",$alphabet);
$a = randomChars($string, 3);
$b = randomChars($string1, 3);
$c = randomChars($string1, 3);
$d = randomChars($string1, 3);
/**
 * Function that retrieves a set number of random characters
 * from a string.
 *
 * @param $str The string that you want to get random characters from.
 * @param $numChars The number of random characters that you want.
 */
function randomChars($str, $numChars){
    //Return the characters.
    return substr(str_shuffle($str), 0, $numChars);
}
?>
<html>
    <head>
    <center>
    <h2>Republic Polytechnic - Authentication</h2>
    </center>
</head>
<body>
<center>
    <h3>Please authenticate your identity</h3>
    <form method="post" action="doAuthy.php">
        <fieldset style="width:325px;">
            <fieldset name="boxone" style="width:100px; margin:0px auto; text-align: center;">
                <a href='doAuthy.php'>
                    <?php
                    print 'Option 1 = '.$a;
                    ?>
                </a>
            </fieldset></br>
            <fieldset name="boxtwo" style="width:100px; margin:0px auto; text-align: center;">
                <a href='doAuthy.php'>
                    <?php
                    print 'Option 2 = '.$b;
                    ?>
                </a>
            </fieldset></br>
            <fieldset name="boxthree" style="width:100px; margin:0px auto; text-align: center;">
                <a href='doAuthy.php'>
                    <?php
                    print 'Option 3 = '.$c;
                    ?>
                </a>
            </fieldset></br>
            <fieldset name="boxfour" style="width:100px; margin:0px auto; text-align: center;">
                <a href='doAuthy.php'>
                    <?php
                    print 'Option 4 = '.$d;
                    ?>
                </a>
            </fieldset></br>
        </fieldset></br>
        <input type="submit" value="Authenticate" name="submit"/>
    </form>
</center>
</body>
</html>