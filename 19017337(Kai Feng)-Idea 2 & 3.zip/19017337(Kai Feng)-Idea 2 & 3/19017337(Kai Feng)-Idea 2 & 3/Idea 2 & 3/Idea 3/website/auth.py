from flask import Blueprint, render_template, redirect, url_for, request, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required, current_user
from .models import User
from . import db
import random

auth = Blueprint('auth', __name__)


@auth.route('/register')
def register1():
    # Graphical---Password---Logic to confuse hacker
    N = 4
    images_ = random.sample(range(10, 26), N * N)
    images = []
    for i in range(0, N * N, N):
        images.append(images_[i:i + N])
    return render_template('register.html', images=images, user=current_user)


@auth.route('/login')
def login1():
    # Graphical---Password---Logic to confuse hacker
    N = 4
    images_ = random.sample(range(10, 26), N * N)
    images = []
    for i in range(0, N * N, N):
        images.append(images_[i:i + N])
    return render_template('login.html', images=images, user=current_user)


@auth.route('/register', methods=['GET', 'POST'])
def register():
    email = request.form.get('email')
    name = request.form.get('name')
    password_1 = sorted(request.form.getlist('password'))
    password_1 = ''.join(map(str, password_1))
    if len(password_1) < 8:
        flash("password must be minimum 4 selections")
        return redirect(url_for('auth.signup'))
    else:
        password = password_1

        # if this returns a user, then the email already exists in database
        user = User.query.filter_by(email=email).first()

    if user:  # if a user is found, we want to redirect back to register page so user can try again
        flash('Email already exists.', category='error')
    elif len(email) < 4:
        flash('Email must be greater than 3 characters.', category='error')
    elif len(name) < 2:
        flash('Username must be greater than 1 character.', category='error')
    else:
        new_user = User(email=email, first_name=name, password=generate_password_hash(
            password, method='sha256'))
        db.session.add(new_user)
        db.session.commit()
        login_user(new_user, remember=True)
        flash('Account created!', category='success')
        return redirect(url_for('views.home'))


@auth.route('/login', methods=['GET', 'POST'])
def login():
    email = request.form.get('email')
    password_1 = sorted(request.form.getlist('password'))
    password_1 = ''.join(map(str, password_1))
    if len(password_1) < 8:
        flash("password must be minimum 4 selections")
        return redirect(url_for('auth.signup'))
    else:
        password = password_1

    user = User.query.filter_by(email=email).first()

    # check if the user actually exists
    # take the user-supplied password, hash it, and compare it to the hashed password in the database
    if not user or not check_password_hash(user.password, password):
        flash('Please check your login details and try again.', category='error')
        return redirect(url_for('auth.login'))  # if the user doesn't exist or password is wrong, reload the page

    # if the above check passes, then we know the user has the right credentials
    flash('Logged in successfully!', category='success')
    login_user(user, remember=True)
    return redirect(url_for('views.home'))
    return render_template("login.html", user=current_user)


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))
